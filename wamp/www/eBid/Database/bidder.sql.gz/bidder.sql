-- phpMyAdmin SQL Dump
-- version 3.3.9
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Jun 09, 2019 at 04:35 PM
-- Server version: 5.1.33
-- PHP Version: 5.3.5

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;

--
-- Database: `bidder`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin`
--

CREATE TABLE IF NOT EXISTS `admin` (
  `name` varchar(15) DEFAULT NULL,
  `password` tinytext,
  `age` int(5) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `admin`
--

INSERT INTO `admin` (`name`, `password`, `age`) VALUES
('Gaurav', 'mittal12', 23);

-- --------------------------------------------------------

--
-- Table structure for table `auctions`
--

CREATE TABLE IF NOT EXISTS `auctions` (
  `Aid` int(10) NOT NULL AUTO_INCREMENT,
  `Date` date DEFAULT NULL,
  `Description` text,
  `image` blob,
  `price` bigint(20) DEFAULT NULL,
  `dealer` varchar(40) DEFAULT NULL,
  `company` varchar(20) DEFAULT NULL,
  `model` text,
  `type` varchar(20) DEFAULT NULL,
  PRIMARY KEY (`Aid`)
) ENGINE=InnoDB  DEFAULT CHARSET=latin1 AUTO_INCREMENT=15 ;

--
-- Dumping data for table `auctions`
--

INSERT INTO `auctions` (`Aid`, `Date`, `Description`, `image`, `price`, `dealer`, `company`, `model`, `type`) VALUES
(5, '2019-03-04', 'pretty one', 0x66616d69692e6a7067, 56000, 'rakesh', 'Mercedes', 'reeli', 'luxury'),
(6, '2019-03-04', 'nice car', 0x646f776e6c6f61642e6a7067, 56000, 'Shrikant', 'audi', 'fcg', 'luxury'),
(7, '2019-03-03', 'Running only 7000 Kms .', 0x62696b652e4a5047, 25000, 'Rahul singh', 'Nissan', 'micra', 'luxury'),
(8, '2019-03-03', 'good car', 0x626964322e6a7067, 23000, 'Sahil', 'hyundai', 'verna', 'luxury'),
(9, '2019-03-12', '23000 Kms running .Condition:good', 0x616c746f2e6a7067, 500000, 'rakesh', 'Maruti suzuki', 'Alto 800', 'sfm'),
(11, '2019-03-10', '12 months used only', 0x72656e61756c742d6475737465722e6a7067, 25000, 'rakesh', 'Renault', 'Duster', 'suv'),
(12, '2019-04-03', 'Very nice Car,please participate in the auction atleast .', 0x68632e6a7067, 120000, 'rakesh', 'Honda', 'City', 'luxury'),
(13, '2019-03-30', 'Hey bidder, this is the nice sports car.hurry to grab the offer.', 0x6c6d62672e6a7067, 50000, 'rakesh', 'Lamborghini', 'sparx', 'sports'),
(14, '2019-06-09', 'Condition is excellent . Used upto 6 months only.', 0x766e75652e6a7067, 600000, 'rakesh', 'Hyundai', 'Venue', 'SUV');

-- --------------------------------------------------------

--
-- Table structure for table `bids`
--

CREATE TABLE IF NOT EXISTS `bids` (
  `Aid` int(10) DEFAULT NULL,
  `bids` int(20) DEFAULT NULL,
  `biddername` varchar(10) DEFAULT NULL,
  KEY `Aid` (`Aid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `bids`
--

INSERT INTO `bids` (`Aid`, `bids`, `biddername`) VALUES
(7, 25000, NULL),
(5, 3400, ''),
(5, 3500, 'Garima'),
(13, 52000, 'Garima'),
(12, 150000, 'Garima'),
(14, 630000, 'bunny');

-- --------------------------------------------------------

--
-- Table structure for table `dealers`
--

CREATE TABLE IF NOT EXISTS `dealers` (
  `name` varchar(40) DEFAULT NULL,
  `mobileno` bigint(11) DEFAULT NULL,
  `password` tinytext,
  `address` text,
  `image` blob
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `dealers`
--

INSERT INTO `dealers` (`name`, `mobileno`, `password`, `address`, `image`) VALUES
('rakesh', 8766656463, 'rakesh765', 'roorkee', 0x32303136303731393131313635302e6a7067),
('Sahil', 9760492859, 'sahil97', 'mumbai', NULL),
('Shrikant', 8171923862, 'shrikant62', 'Ranchi', NULL),
('Radhika khanna', 7080906856, 'radhika7080', 'shirdi', NULL),
('Rahul singh', 9897337723, 'rahulsingh', 'Saharanpur', NULL);

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE IF NOT EXISTS `users` (
  `name` varchar(40) DEFAULT NULL,
  `password` tinytext,
  `mobileno` bigint(11) DEFAULT NULL,
  `Address` text,
  `image` blob,
  `Username` text
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`name`, `password`, `mobileno`, `Address`, `image`, `Username`) VALUES
('bunny', 'hunny23', 8755969548, '1/85,grand plazashivaji chowk sre', 0x494d472d32303137303530312d5741303036382e6a7067, NULL),
('Garima', 'garima34', 8655757623, 'saharanpur,up', 0x73687261646468612d6b61706f6f722e6a7067, NULL),
('neha', 'neha54', 6478844, 'sre', 0x31302e6a7067, NULL),
('Ragini', 'ragini87', 9897223344, 'saharanpur,up', 0x696d61676573202831292e6a7067, NULL),
('rehan', 'rehan67', 7906916008, 'saharanpur,up', 0x31352e6a7067, NULL),
('garvit', 'garvit89', 8979122231, 'saharanpur,up', 0x32303136303731383132303635362e6a7067, NULL),
('shubham', 'shubhamnj', 8655757623, 'Delhi NCR', NULL, NULL),
('Divyansh Mittal', 'divyansh', 9897477739, 'Delhi NCR', 0x31323134343135315f313135353535323633343435353032335f3139343635303530365f6e2e6a7067, NULL),
('Ramesh Pokhriyal', 'rameshpo', 946, 'Dehradun', NULL, 'Ramesh Pokhriyal19');

-- --------------------------------------------------------

--
-- Table structure for table `winners`
--

CREATE TABLE IF NOT EXISTS `winners` (
  `Aid` int(10) DEFAULT NULL,
  `winner` varchar(40) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `winners`
--


--
-- Constraints for dumped tables
--

--
-- Constraints for table `bids`
--
ALTER TABLE `bids`
  ADD CONSTRAINT `bids_ibfk_1` FOREIGN KEY (`Aid`) REFERENCES `auctions` (`Aid`);
